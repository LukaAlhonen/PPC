#pragma once

void correlate(int ny, int nx, const float *data, float *result);
